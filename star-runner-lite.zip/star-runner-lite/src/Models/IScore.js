class IScore {
  save(score) {
    throw new Error("Method not implemented");
  }

  getAll() {
    throw new Error("Method not implemented");
  }
}

