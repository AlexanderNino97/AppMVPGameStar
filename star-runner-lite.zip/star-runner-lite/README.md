# star-runner-lite
Mini videojuego con Node.js y Kaboom.js para evaluar patrones de diseño y trabajo colaborativo con GitFlow.